module.exports = function(fs, month){
    let data = fs.readFileSync('./assets/employes.json', 'utf8');
    data = JSON.parse(data);

    data.forEach(k => {
        delete k.Email,
        delete k.Setor,
        delete k.ramal;
    });

    const filterData = data.filter(k => {
        const birth = 'Data_de_nascimento';
        const birthMonth = new Date(k[birth]).getMonth();
        return (birthMonth === month-1);
    });
    return filterData;
}