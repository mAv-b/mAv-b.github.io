module.exports = function(fs, sectorName){
    let data = fs.readFileSync('./assets/employes.json');
    data = JSON.parse(data);

    data.forEach(k =>{
        delete k.Data_de_nascimento,
        delete k.ramal,
        delete k.Email;
    })

    const filterData = data.filter(k =>{
        return (k.Setor === sectorName);
    });
    return filterData;
};