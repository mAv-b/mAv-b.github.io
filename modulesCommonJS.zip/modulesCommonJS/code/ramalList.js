module.exports = function(fs){
    let data = fs.readFileSync('./assets/employes.json', 'utf8');
    data = JSON.parse(data);

    data.forEach(item => {
        delete item.Email, 
        delete item.Data_de_nascimento,
        delete item.Setor;
    });

    const sortData = data.sort((a,b) =>{
        let i = 0;
        const nomeA = a.Nome_Completo;
        const nomeB = b.Nome_Completo;
        while(i < nomeA.length){
            if(nomeA[i] != nomeB[i]){
                return ((nomeA < nomeB)? -1:1);
            }
            else{
                i++;
            }
        }
        return -1;
    });
    return sortData;
};