const configReturns = require('./config/config.js')();
const app = configReturns[0];
const fs = configReturns[1];
const port = 2626;

const code = {
    sectorListCode : require('./code/searchBySector.js'),
    birthListCode : require('./code/BirthList.js'),
    ramalListCode : require('./code/ramalList.js')
};
const reqCodes = [code.birthListCode, code.sectorListCode, code.ramalListCode];

const route_root = require('./routes/root.js')(app, fs, reqCodes);

app.listen(port, ()=>{
    const server = '192.168.1.111';
    console.log('http://%s:%s', server, port);
    console.log(`Use esses valores para o parametro filter 
    \n'birth-month-list','sector-list','ramal-list' na rota '/'`);
    console.log('Por exemplo: http://localhost:2626/?filter=sector-list&search=Engineering')
});