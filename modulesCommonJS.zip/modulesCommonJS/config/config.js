const express = require('express');
const fs = require('fs');


module.exports = function(){
    return [express(),fs];
};