module.exports = function(app, fs, dataStorage){
    app.get('/', (req,res)=>{
        const filter = req.query.filter;
        const search = req.query.search;
        const options = ['birth-month-list','sector-list','ramal-list'];
        const reqId = options.indexOf(filter);

        (reqId === -1)? deniedReq():allowReq();
        
        function deniedReq(){
            res.send(`Request denied 404.
                \nInvalid Value of 'filter'
            `);
        }
        function allowReq(){
            res.send(dataStorage[reqId](fs,search));
        }

    })
}